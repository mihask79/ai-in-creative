from __future__ import annotations

import hashlib
import json
import zipfile
from pathlib import Path

from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.shared import Inches, Pt, RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

ROOT = Path(__file__).parent
data = json.loads((ROOT / "artifacts/results.json").read_text(encoding="utf-8"))
doc = Document()
sec = doc.sections[0]
sec.top_margin = Inches(.7)
sec.bottom_margin = Inches(.7)
sec.left_margin = Inches(.8)
sec.right_margin = Inches(.8)
style = doc.styles["Normal"]
style.font.name = "Times New Roman"
style.font.size = Pt(11)
style.paragraph_format.space_after = Pt(5)
for name in ("Title", "Heading 1", "Heading 2"):
    doc.styles[name].font.name = "Times New Roman"
    doc.styles[name].font.color.rgb = RGBColor(0, 0, 0)

def para(text="", bold=False, italic=False):
    p = doc.add_paragraph()
    r = p.add_run(text)
    r.bold, r.italic = bold, italic
    return p

def table(headers, rows):
    t = doc.add_table(rows=1, cols=len(headers))
    t.style = "Light Shading Accent 1"
    borders = OxmlElement('w:tblBorders')
    for side in ('top', 'left', 'bottom', 'right', 'insideH', 'insideV'):
        edge = OxmlElement('w:' + side)
        for key, value in [('val', 'single'), ('sz', '4'), ('color', 'D9D9D9')]:
            edge.set(qn('w:' + key), value)
        borders.append(edge)
    t._tbl.tblPr.append(borders)
    for c, val in zip(t.rows[0].cells, headers):
        c.text = str(val)
        for r in c.paragraphs[0].runs:
            r.bold = True
    for row in rows:
        cells = t.add_row().cells
        for c, val in zip(cells, row):
            c.text = str(val)
    doc.add_paragraph()
    return t

title = doc.add_paragraph(style="Title")
title.alignment = WD_ALIGN_PARAGRAPH.CENTER
title.add_run("Лабораторная работа № 1\nПодготовка среды и паспорт воспроизводимого AI эксперимента")
for line in ["Дисциплина: Искусственный интеллект в креативных технологиях",
             "Направление: 09.04.02 Информационные системы и технологии",
             "Студент: Скрыпник Михаил Дмитриевич   Группа: МИК11",
             "Вариант 1",
             "Дата выполнения: 13.10.2026"]:
    p = para(line)
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER

doc.add_heading("1. Цель и постановка", level=1)
para("Цель — подготовить изолированную среду Python, зафиксировать условия вычислительного эксперимента и проверить воспроизводимость измерениями. Рассматривается учебный генератор процедурной текстуры; реальная генеративная модель в этой работе не используется.")
para("Вариант 1 задаёт контекст «облачное небо для фона афиши»: размер 96 × 96 пикселей, шаг решётки 32, четыре октавы, затухание 0,50, сглаженная интерполяция, квантование 8 бит. Изменяемый фактор — увеличение размера изображения в 1,5 раза (96 → 144) при неизменности остальных параметров.")
para("До запуска зафиксирована гипотеза: увеличение размера изображения при тех же параметрах текстуры не должно менять метрики заметнее обычного разброса между seed. Порог учебного критерия заранее принят равным 2: эффект считается существенным, если |разность средних| / s_baseline > 2, где s_baseline — выборочное стандартное отклонение пяти базовых измерений.")
para("", italic=True)

doc.add_heading("2. Среда и ход работы", level=1)
table(["Пункт", "Зафиксированное состояние"], [
    ("ОС и архитектура", "Windows 11 x64 (10.0.26300), сведения из среды выполнения проекта"),
    ("Интерпретатор", "CPython 3.12.14; удовлетворяет требованию Python ≥ 3.10"),
    ("Изоляция", "Локальная .venv; команды выполнялись через .venv\\Scripts\\python.exe"),
    ("Пакеты", "Сторонние пакеты не используются; pip freeze в .venv пуст"),
    ("zlib", data["environment"]["zlib"]),
    ("Создание среды", "python -m venv .venv"),
    ("Команда эксперимента", ".venv\\Scripts\\python.exe src\\lab01_experiment.py --variant 1 --out artifacts"),
])
para("Ход работы: создана виртуальная среда; дважды запущена демонстрация без seed и дважды с фиксированным seed 101; выполнен эксперимент для базовых параметров и фактора на seed 101–105; рассчитаны SHA-256 массивов пикселей и четыре метрики. Активация PowerShell-среды не выполнялась: использовался прямой путь к интерпретатору виртуальной среды.")

doc.add_heading("3. Паспорт эксперимента", level=1)
table(["Поле паспорта", "Запись", "Зачем фиксируется"], [
    ("Цель и критерий", "Оценить воспроизводимость и влияние размера 96 → 144; порог |Δ|/s > 2", "Позволяет заранее определить, что считать эффектом"),
    ("Данные и лицензия", "Синтетические пиксели генератора; внешние данные не применяются; лицензия набора не требуется", "Указывает происхождение и правовой статус входа"),
    ("Генератор", "Учебный процедурный генератор, версия 1.0; код в src/lab01_generator.py", "Определяет вычислительную процедуру"),
    ("Версия кода", "SHA-256 исходников записаны в таблице ниже", "Позволяет отличить изменённый скрипт"),
    ("Параметры", "Размер 96/144; cell 32; 4 октавы; persistence 0,50; smooth; 8 бит", "Определяет содержание каждого запуска"),
    ("Случайность", "Локальный random.Random(seed); seed 101–105; воспроизводимость дополнительно проверена на 101 и 1101", "Исключает зависимость от общего состояния генератора"),
    ("Среда", "Windows 11 x64; CPython 3.12.14; zlib 1.3.2; сторонних библиотек нет", "Фиксирует возможные программные различия"),
    ("Процедура", "Команда запуска приведена в разделе 2; журнал — reports/lab_journal.txt", "Даёт точные шаги повторения"),
    ("Результаты", "Полный JSON, хеши изображений и метрики — artifacts/results.json", "Сохраняет измеренный результат и его контрольные суммы"),
    ("Ограничения", "5 seed; один генератор и одна текстура; учебный порог не является статистическим тестом", "Очерчивает границы допустимых выводов"),
])
hash_rows=[]
for name in ("src/lab01_generator.py", "src/lab01_experiment.py", "src/seed_demo.py"):
    digest=hashlib.sha256((ROOT/name).read_bytes()).hexdigest()
    hash_rows.append((name, digest))
table(["Файл кода", "SHA-256"], hash_rows)

doc.add_heading("4. Воспроизводимость", level=1)
eq=data["reproducibility"]
table(["Проверка", "Результат"], [(k, str(v).lower()) for k,v in eq.items()])
para("SHA-256 полного массива пикселей, запуск с seed 101: " + data["pixel_sha256_prefix16"][0])
para("При seed 1101 получен другой отпечаток: " + data["pixel_sha256_prefix16"][2])
def seed_record(filename):
    lines=(ROOT/"artifacts"/filename).read_text(encoding="utf-8").splitlines()
    line=next(x for x in lines if x.startswith("seed="))
    parts=line.split()
    return parts[0].split("=")[1], parts[1].split("=")[1]
u1,h1=seed_record("seed_demo_unfixed_1.txt")
u2,h2=seed_record("seed_demo_unfixed_2.txt")
f1,hf1=seed_record("seed_demo_fixed_1.txt")
f2,hf2=seed_record("seed_demo_fixed_2.txt")
para(f"Без --seed получены системные значения {u1} и {u2} и разные SHA-256 {h1[:16]}… и {h2[:16]}…. С seed 101 два запуска дали {hf1[:16]}… и {hf2[:16]}…. Это демонстрирует, почему seed требуется задавать и записывать.")

doc.add_heading("5. Метрики и изображения", level=1)
para("Таблица показывает среднее по пяти запускам и выборочное стандартное отклонение базового условия. Решение по фактору использует заранее заданное отношение |Δ|/s_baseline.")
rows=[]
labels={"mean":"Среднее яркости", "contrast":"Контраст", "edge_energy":"Граничная энергия", "entropy_bits":"Энтропия, бит"}
for k,v in data["metrics"].items():
    rows.append((labels[k], f'{v["baseline_mean"]:.6f}', f'{v["baseline_sample_sd"]:.6f}',
                 f'{v["factor_mean"]:.6f}', f'{v["delta"]:+.6f}',
                 f'{v["abs_delta_over_baseline_sd"]:.3f}', "существенно" if v["substantial_at_threshold_2"] else "не обнаружено"))
table(["Метрика", "База: среднее", "База: s", "Фактор: среднее", "Δ", "|Δ|/s", "Вывод при пороге 2"], rows)
para("На рис. 1 показаны изображения seed 101, размером 96×96 и 144×144, приведённые к одинаковому размеру отображения. SHA-256 PNG: базовое условие " + data["png_sha256"]["baseline_seed101.png"] + "; фактор " + data["png_sha256"]["factor_seed101.png"] + ". Для проверки точного совпадения пикселей использовались хеши массивов, а не хеш PNG.")
imgs=doc.add_table(rows=1, cols=2)
for cell, label, path in zip(imgs.rows[0].cells, ["База · 96×96 · cell 32", "Фактор · 144×144 · cell 32"],
                             [ROOT/"artifacts/baseline_seed101.png", ROOT/"artifacts/factor_seed101.png"]):
    cell.paragraphs[0].alignment=WD_ALIGN_PARAGRAPH.CENTER
    cell.paragraphs[0].add_run(label+"\n")
    cell.paragraphs[0].add_run().add_picture(str(path), width=Inches(2.35))
cap=para("Рисунок 1 — Сравнение текстур для seed 101")
cap.alignment=WD_ALIGN_PARAGRAPH.CENTER

doc.add_heading("6. Анализ, ограничения и вывод", level=1)
para("Решение по каждой метрике дано в таблице на основе учебного критерия. Результат относится только к данной процедурной текстуре и выбранным параметрам; он не обобщается на все изображения или генеративные модели.")
para("Разброс оценивается всего по пяти seed; порог 2 — заранее заданное учебное правило, а не статистический тест. Проверена одна текстура и один фактор. Метрики описывают распределение яркости и соседние пиксели, но не художественное качество. Нельзя заключать, что фактор универсально улучшает или ухудшает изображения. Отсутствие обнаруженного эффекта для среднего не доказывает его отсутствия.")
para("Вывод по цели: изолированная среда подготовлена; зафиксированы версии, параметры, seed и контрольные суммы; сравнение повторов подтвердило воспроизводимость для фиксированного seed и выявило ожидаемую невоспроизводимость при пропуске seed. Влияние фактора не обнаружено ни по одной из четырёх метрик согласно порогу, записанному до анализа.")
para("Часть Б по Engee не выполнялась: методичка предписывает проводить её по указанию преподавателя. Версии среды, вывод Julia и изменения переменных в паспорте не заявляются, поскольку фактическая сессия Engee не запускалась.", italic=True)

para("Для афиши средняя яркость около 0,48–0,50 и плавные переходы облаков подходят как исходная подложка. Однако общие метрики не гарантируют читаемость заголовка: его нужно проверять в выбранной области фона; при недостаточном локальном контрасте добавить однотонную подложку или изменить цвет текста.")
para("Сопоставление с демонстрацией методички: базовый SHA-256 начинается с 93fae5913d797284, базовые средние совпали после округления. Факторные метрики отличаются от демонстрационных; в отчёте оставлены фактические значения данной реализации. В обоих случаях порог 2 не превышен. Разница среды и отсутствие исходного скрипта автора не позволяют установить причину расхождения по одному отчёту.")

doc.add_heading("7. Ответы на контрольные вопросы", level=1)
para("1. Один запуск не характеризует разброс результата между случайными начальными состояниями. Вместо него сообщают серию запусков с записанными seed, метрики каждого или их среднее и выборочное стандартное отклонение, а также условия и контрольные суммы.")
para("6. Если код не менялся, сначала дважды повторяют команду и сравнивают хеши полных массивов, затем проверяют предупреждения и источник seed. В демонстрации без --seed seed берётся из времени, поэтому запуски различаются. Исправление — явно задавать seed и использовать локальный random.Random(seed).")

doc.add_heading("8. Состав передаваемых материалов", level=1)
para("В папке работы находятся исходный код генератора и эксперимента, скрипт демонстрации seed, пустой список сторонних зависимостей, журнал, файл результатов JSON, два изображения и этот отчёт с паспортом. Папка .venv локальная и исключена из контроля версий; для восстановления её создают командой python -m venv .venv.")
para("Архив материалов: artifacts/lr01_variant01_artifacts.zip. Он содержит код, результаты, изображения, журнал и этот паспорт с отчётом.")

out=ROOT/"reports/ЛР01_Отчет_и_паспорт.docx"
doc.save(out)
print(out)
archive = ROOT / 'artifacts/lr01_variant01_artifacts.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as z:
    for p in sorted(ROOT.rglob('*')):
        rel = p.relative_to(ROOT)
        if p.is_file() and '.venv' not in rel.parts and '__pycache__' not in rel.parts and p.suffix != '.zip':
            z.write(p, rel.as_posix())
print(archive)
